export type PrepaymentType = 'one-time' | 'recurring-monthly' | 'recurring-yearly';
export type PrepaymentTarget = 'reduce-tenure' | 'reduce-emi';

export interface LoanInputs {
  principal: number; // in INR
  interestRate: number; // annual percentage e.g. 8.5
  tenureYears: number; // tenure in years
  tenureMonths: number; // total months
  startDate: string; // YYYY-MM
  hasPrepayment: boolean;
  prepaymentType: PrepaymentType;
  prepaymentAmount: number; // in INR
  prepaymentStartMonth: number; // 1-indexed month number
  prepaymentTarget: PrepaymentTarget;
}

export interface MonthlyScheduleItem {
  monthIndex: number; // 1 to total
  yearIndex: number; // 1 to total years
  monthInYear: number; // 1 to 12
  dateLabel: string; // e.g., "Nov 2026"
  openingBalance: number;
  emi: number;
  interest: number;
  principal: number;
  prepayment: number;
  totalMonthlyPaid: number;
  closingBalance: number;
  loanProgressPercent: number; // % of original loan paid off so far
}

export interface YearlyScheduleItem {
  yearIndex: number;
  yearLabel: string;
  openingBalance: number;
  totalEMI: number;
  totalPrincipal: number;
  totalInterest: number;
  totalPrepayment: number;
  totalPaid: number;
  closingBalance: number;
  months: MonthlyScheduleItem[];
}

export interface LoanCalculationResult {
  // Baseline without prepayment
  baseEMI: number;
  baseTotalInterest: number;
  baseTotalPayment: number;
  baseTenureMonths: number;
  basePayoffDate: string;

  // Actual with prepayment
  actualEMI: number;
  actualTotalInterest: number;
  actualTotalPayment: number;
  actualTenureMonths: number;
  actualPayoffDate: string;
  totalPrepaymentPaid: number;

  // Savings
  interestSaved: number;
  interestSavedPercent: number;
  tenureMonthsSaved: number;
  tenureYearsSaved: number;

  // Visual breakdown
  principalRatio: number;
  interestRatio: number;

  // Full schedules
  monthlySchedule: MonthlyScheduleItem[];
  yearlySchedule: YearlyScheduleItem[];
  baseMonthlySchedule: MonthlyScheduleItem[];
}
