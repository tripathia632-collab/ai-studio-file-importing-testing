import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { LoanInputsPanel } from './components/LoanInputs';
import { LoanSummaryCards } from './components/LoanSummaryCards';
import { LoanCharts } from './components/LoanCharts';
import { AmortizationSchedule } from './components/AmortizationSchedule';
import { PrintStatement } from './components/PrintStatement';
import { LoanInputs } from './types/loan';
import { calculateFullLoan } from './utils/loanCalculations';
import { downloadScheduleCSV, copySummaryToClipboard } from './utils/exportHelpers';
import {
  Download,
  Printer,
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  Lightbulb,
} from 'lucide-react';

const DEFAULT_INPUTS: LoanInputs = {
  principal: 2500000, // 25 Lakhs
  interestRate: 8.5, // 8.5% p.a.
  tenureYears: 20,
  tenureMonths: 240,
  startDate: '2026-11',
  hasPrepayment: true,
  prepaymentType: 'one-time',
  prepaymentAmount: 100000, // 1 Lakh at Month 12
  prepaymentStartMonth: 12,
  prepaymentTarget: 'reduce-tenure',
};

export default function App() {
  const [inputs, setInputs] = useState<LoanInputs>(DEFAULT_INPUTS);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  // Recalculate loan data whenever inputs change
  const loanResult = useMemo(() => {
    return calculateFullLoan(inputs);
  }, [inputs]);

  const handleDownloadCSV = () => {
    downloadScheduleCSV(loanResult.monthlySchedule, inputs, loanResult);
    showToast('Amortization schedule downloaded as CSV');
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopySummary = async () => {
    const success = await copySummaryToClipboard(inputs, loanResult);
    if (success) {
      showToast('Executive loan summary copied to clipboard');
    }
  };

  const handleReset = () => {
    setInputs(DEFAULT_INPUTS);
    showToast('Calculator reset to default parameters');
  };

  // Quick scenario triggers for user convenience
  const applyScenario = (type: 'extra-emi' | 'lump-bonus' | 'clear-prepay') => {
    if (type === 'extra-emi') {
      const extraMonthly = Math.round(loanResult.baseEMI * 0.1); // ~1 extra EMI per year
      setInputs((prev) => ({
        ...prev,
        hasPrepayment: true,
        prepaymentType: 'recurring-monthly',
        prepaymentAmount: extraMonthly,
        prepaymentStartMonth: 1,
        prepaymentTarget: 'reduce-tenure',
      }));
      showToast('Applied: 10% Extra Monthly Prepayment scenario');
    } else if (type === 'lump-bonus') {
      setInputs((prev) => ({
        ...prev,
        hasPrepayment: true,
        prepaymentType: 'recurring-yearly',
        prepaymentAmount: 100000,
        prepaymentStartMonth: 12,
        prepaymentTarget: 'reduce-tenure',
      }));
      showToast('Applied: ₹1 Lakh Annual Bonus Prepayment');
    } else if (type === 'clear-prepay') {
      setInputs((prev) => ({
        ...prev,
        hasPrepayment: false,
      }));
      showToast('Prepayment disabled');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col antialiased">
      {/* Top Bar Navigation */}
      <Header onPrint={handlePrint} onDownloadCSV={handleDownloadCSV} />

      {/* Printable Statement for PDF / Print Output */}
      <div className="printable-area max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 w-full">
        <PrintStatement inputs={inputs} result={loanResult} />

        {/* Main Application Container */}
        <main className="flex flex-col gap-8 no-print pb-16">
          {/* Top Banner / Hero Title */}
          <div className="pt-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                  Loan EMI & Prepayment Calculator
                </h1>
                <p className="text-sm text-slate-500 mt-1 max-w-2xl text-balance">
                  Calculate accurate monthly EMI, amortized interest breakdown, and discover how
                  strategic prepayments save lakhs of rupees and shave years off your tenure.
                </p>
              </div>

              {/* Utility Action Buttons */}
              <div className="flex items-center gap-2 self-start sm:self-auto">
                <button
                  type="button"
                  onClick={handleCopySummary}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 hover:text-slate-900 rounded-lg shadow-xs transition-colors"
                >
                  <Copy className="w-3.5 h-3.5 text-slate-500" />
                  <span>Copy Summary</span>
                </button>
                <button
                  type="button"
                  onClick={handleReset}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 hover:text-slate-900 rounded-lg shadow-xs transition-colors"
                  title="Reset to default ₹25 Lakhs @ 8.5%"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset</span>
                </button>
              </div>
            </div>

            {/* Quick Strategy Presets */}
            <div className="mt-4 flex flex-wrap items-center gap-2 pt-2 border-t border-slate-200 text-xs">
              <span className="text-slate-500 font-medium flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                Quick Prepayment Scenarios:
              </span>
              <button
                type="button"
                onClick={() => applyScenario('extra-emi')}
                className="px-2.5 py-1 rounded-md bg-white border border-slate-200 text-slate-700 hover:border-blue-400 hover:text-blue-600 transition-colors font-medium shadow-2xs"
              >
                +10% Extra Monthly (Save ~3-4 yrs)
              </button>
              <button
                type="button"
                onClick={() => applyScenario('lump-bonus')}
                className="px-2.5 py-1 rounded-md bg-white border border-slate-200 text-slate-700 hover:border-blue-400 hover:text-blue-600 transition-colors font-medium shadow-2xs"
              >
                ₹1 Lakh Annual Prepayment
              </button>
              {inputs.hasPrepayment && (
                <button
                  type="button"
                  onClick={() => applyScenario('clear-prepay')}
                  className="px-2.5 py-1 rounded-md bg-white border border-slate-200 text-slate-500 hover:text-slate-700 transition-colors font-medium shadow-2xs"
                >
                  Turn Off Prepayment
                </button>
              )}
            </div>
          </div>

          {/* 2-Column Responsive Workspace Grid: Inputs on Left, Analytics on Right */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Column: Loan Inputs */}
            <section id="calculator-section" className="lg:col-span-5 w-full">
              <LoanInputsPanel inputs={inputs} onChange={setInputs} />
            </section>

            {/* Right Column: Summary Cards + Visual Charts */}
            <div className="lg:col-span-7 flex flex-col gap-6 w-full">
              {/* Summary Cards */}
              <section id="summary-section">
                <LoanSummaryCards inputs={inputs} result={loanResult} />
              </section>

              {/* Principal and Interest Chart */}
              <section id="charts-section">
                <LoanCharts inputs={inputs} result={loanResult} />
              </section>
            </div>
          </div>

          {/* Month-wise Amortization Schedule (Full Width) */}
          <section id="schedule-section">
            <AmortizationSchedule
              inputs={inputs}
              result={loanResult}
              onDownloadCSV={handleDownloadCSV}
              onPrint={handlePrint}
            />
          </section>

          {/* Financial Guidance & Smart Tips Section */}
          <section className="bg-white border border-slate-200 rounded-xl p-6 shadow-xs">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-base mb-3">
              <Lightbulb className="w-5 h-5 text-amber-500" />
              <span>Smart Borrowing Insights: How Prepayments Work</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-600 leading-relaxed">
              <div>
                <h3 className="font-bold text-slate-800 text-sm mb-1">
                  1. Interest is Front-Loaded
                </h3>
                <p>
                  In the early years of any reducing-balance loan, over 60–75% of your monthly EMI
                  goes toward interest payments, not principal. Making early prepayments knocks down
                  the compounding balance immediately.
                </p>
              </div>
              <div>
                <h3 className="font-bold text-slate-800 text-sm mb-1">
                  2. Tenure Reduction vs EMI Reduction
                </h3>
                <p>
                  Choosing <span className="font-semibold text-slate-900">Reduce Tenure</span> keeps
                  your monthly budget constant while drastically shortening the loan life and
                  maximizing total interest savings.
                </p>
              </div>
              <div>
                <h3 className="font-bold text-slate-800 text-sm mb-1">
                  3. Zero Prepayment Penalties
                </h3>
                <p>
                  Under RBI regulations in India, banks and NBFCs cannot charge prepayment or
                  foreclosure penalties on floating-rate home loans sanctioned to individual
                  borrowers.
                </p>
              </div>
            </div>
          </section>
        </main>
      </div>

      {/* Schedule Table when Printing (Shown in print mode directly) */}
      <div className="hidden print-only max-w-7xl mx-auto px-4 w-full">
        <AmortizationSchedule
          inputs={inputs}
          result={loanResult}
          onDownloadCSV={handleDownloadCSV}
          onPrint={handlePrint}
        />
      </div>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-200 bg-white py-6 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">RupeeLoan Calculator</span>
            <span>·</span>
            <span>Accurate reducing-balance EMI & prepayment simulation</span>
          </div>
          <div>
            <span>Values formatted in Indian Standard (Lakhs & Crores)</span>
          </div>
        </div>
      </footer>

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white text-xs font-medium px-4 py-3 rounded-lg shadow-xl flex items-center gap-2 border border-slate-700 transition-all duration-200 animate-in fade-in slide-in-from-bottom-2">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
