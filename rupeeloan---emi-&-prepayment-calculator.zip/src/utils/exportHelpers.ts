import { LoanInputs, LoanCalculationResult, MonthlyScheduleItem } from '../types/loan';
import { formatINR } from './loanCalculations';

/**
 * Generates and triggers download of the complete month-wise amortization schedule as CSV.
 */
export function downloadScheduleCSV(
  schedule: MonthlyScheduleItem[],
  inputs: LoanInputs,
  result: LoanCalculationResult
): void {
  const lines: string[] = [];

  // Metadata block
  lines.push('RupeeLoan EMI & Prepayment Amortization Statement');
  lines.push(`Generated On,"${new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}"`);
  lines.push('');
  lines.push('LOAN PARAMETERS');
  lines.push(`Loan Amount (Principal),"₹ ${inputs.principal.toLocaleString('en-IN')}"`);
  lines.push(`Annual Interest Rate,"${inputs.interestRate}%"`);
  lines.push(`Loan Tenure,"${inputs.tenureYears} Years (${inputs.tenureMonths} Months)"`);
  lines.push(`Start Month,"${schedule[0]?.dateLabel || ''}"`);
  lines.push(`Monthly EMI,"₹ ${Math.round(result.actualEMI).toLocaleString('en-IN')}"`);

  if (inputs.hasPrepayment) {
    lines.push('');
    lines.push('PREPAYMENT IMPACT');
    lines.push(`Prepayment Type,"${inputs.prepaymentType}"`);
    lines.push(`Prepayment Amount,"₹ ${inputs.prepaymentAmount.toLocaleString('en-IN')}"`);
    lines.push(`Strategy,"${inputs.prepaymentTarget === 'reduce-tenure' ? 'Reduce Loan Tenure' : 'Reduce Monthly EMI'}"`);
    lines.push(`Total Interest Saved,"₹ ${Math.round(result.interestSaved).toLocaleString('en-IN')} (${result.interestSavedPercent.toFixed(1)}%)"`);
    lines.push(`Tenure Shortened By,"${result.tenureMonthsSaved} Months (${result.tenureYearsSaved} Years)"`);
    lines.push(`Actual Payoff Date,"${result.actualPayoffDate}"`);
  }

  lines.push('');
  lines.push('MONTHLY AMORTIZATION SCHEDULE');
  // Column headers
  lines.push([
    'Month #',
    'Date',
    'Opening Balance (₹)',
    'EMI (₹)',
    'Principal Paid (₹)',
    'Interest Charged (₹)',
    'Prepayment (₹)',
    'Total Paid (₹)',
    'Closing Balance (₹)',
    'Paid Off %',
  ].join(','));

  // Rows
  schedule.forEach((m) => {
    lines.push([
      m.monthIndex,
      `"${m.dateLabel}"`,
      Math.round(m.openingBalance),
      Math.round(m.emi),
      Math.round(m.principal),
      Math.round(m.interest),
      Math.round(m.prepayment),
      Math.round(m.totalMonthlyPaid),
      Math.round(m.closingBalance),
      `${m.loanProgressPercent.toFixed(1)}%`,
    ].join(','));
  });

  // Footer summary
  lines.push('');
  lines.push([
    'TOTALS',
    '-',
    '-',
    Math.round(result.actualTotalPayment - result.totalPrepaymentPaid),
    Math.round(inputs.principal),
    Math.round(result.actualTotalInterest),
    Math.round(result.totalPrepaymentPaid),
    Math.round(result.actualTotalPayment),
    0,
    '100%',
  ].join(','));

  const csvContent = '\uFEFF' + lines.join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `Loan_Amortization_Schedule_${inputs.principal}_INR.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Formats a clean executive summary text to copy to clipboard.
 */
export async function copySummaryToClipboard(
  inputs: LoanInputs,
  result: LoanCalculationResult
): Promise<boolean> {
  const text = [
    `📊 Loan EMI Summary (RupeeLoan)`,
    `───────────────────────────────`,
    `💰 Loan Amount: ${formatINR(inputs.principal)}`,
    `📈 Interest Rate: ${inputs.interestRate}% p.a.`,
    `⏱️ Tenure: ${inputs.tenureYears} Years (${inputs.tenureMonths} Months)`,
    `💳 Monthly EMI: ${formatINR(result.actualEMI)}`,
    `🏦 Total Interest: ${formatINR(result.actualTotalInterest)}`,
    `💵 Total Payment: ${formatINR(result.actualTotalPayment)}`,
    `🏁 Payoff Date: ${result.actualPayoffDate}`,
    inputs.hasPrepayment && result.interestSaved > 0
      ? `\n🎯 Prepayment Benefit:\n• Interest Saved: ${formatINR(result.interestSaved)} (${result.interestSavedPercent.toFixed(1)}%)\n• Tenure Reduced: ${result.tenureMonthsSaved} months (${result.tenureYearsSaved} yrs)`
      : '',
  ].filter(Boolean).join('\n');

  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}
