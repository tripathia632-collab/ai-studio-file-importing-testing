import {
  LoanInputs,
  LoanCalculationResult,
  MonthlyScheduleItem,
  YearlyScheduleItem,
} from '../types/loan';

/**
 * Computes standard monthly EMI given principal P, annual rate R (in percent), and tenure n (in months).
 */
export function calculateEMI(principal: number, annualRatePercent: number, totalMonths: number): number {
  if (principal <= 0 || totalMonths <= 0) return 0;
  if (annualRatePercent <= 0) {
    return principal / totalMonths;
  }
  const monthlyRate = annualRatePercent / 12 / 100;
  const factor = Math.pow(1 + monthlyRate, totalMonths);
  const emi = (principal * monthlyRate * factor) / (factor - 1);
  return emi;
}

/**
 * Formats a date label given a start date "YYYY-MM" and a 0-indexed month offset.
 */
export function getDateLabel(startYearMonth: string, monthOffset: number): { label: string; year: number; month: number } {
  let [startYear, startMonth] = [2026, 11];
  if (startYearMonth && startYearMonth.includes('-')) {
    const parts = startYearMonth.split('-');
    startYear = parseInt(parts[0], 10) || 2026;
    startMonth = parseInt(parts[1], 10) || 11;
  }

  // month is 1-indexed (1 = Jan)
  const totalMonths = (startYear * 12) + (startMonth - 1) + monthOffset;
  const targetYear = Math.floor(totalMonths / 12);
  const targetMonth = (totalMonths % 12) + 1;

  const date = new Date(targetYear, targetMonth - 1, 1);
  const label = date.toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
  return { label, year: targetYear, month: targetMonth };
}

/**
 * Simulates a loan month-by-month either with or without prepayment.
 */
function simulateSchedule(
  inputs: LoanInputs,
  applyPrepayment: boolean
): {
  monthlySchedule: MonthlyScheduleItem[];
  yearlySchedule: YearlyScheduleItem[];
  totalInterest: number;
  totalPayment: number;
  totalPrepayment: number;
  monthsCount: number;
  payoffDate: string;
} {
  const {
    principal,
    interestRate,
    tenureMonths,
    startDate,
    prepaymentType,
    prepaymentAmount,
    prepaymentStartMonth,
    prepaymentTarget,
  } = inputs;

  const monthlyRate = interestRate > 0 ? interestRate / 12 / 100 : 0;
  let currentBalance = principal;
  let currentEMI = calculateEMI(principal, interestRate, tenureMonths);

  const monthlySchedule: MonthlyScheduleItem[] = [];
  let totalInterest = 0;
  let totalPayment = 0;
  let totalPrepayment = 0;
  let monthIndex = 0;
  const maxSafetyMonths = tenureMonths * 2; // prevent infinite loops in weird scenarios

  while (currentBalance > 0.5 && monthIndex < maxSafetyMonths) {
    monthIndex++;
    const openingBalance = currentBalance;
    const dateInfo = getDateLabel(startDate, monthIndex - 1);

    // Calculate interest for this month
    const interestForMonth = openingBalance * monthlyRate;

    // Check if prepayment applies this month
    let prepaymentForMonth = 0;
    if (applyPrepayment && inputs.hasPrepayment && prepaymentAmount > 0) {
      if (prepaymentType === 'one-time' && monthIndex === prepaymentStartMonth) {
        prepaymentForMonth = prepaymentAmount;
      } else if (prepaymentType === 'recurring-monthly' && monthIndex >= prepaymentStartMonth) {
        prepaymentForMonth = prepaymentAmount;
      } else if (prepaymentType === 'recurring-yearly' && monthIndex >= prepaymentStartMonth && (monthIndex - prepaymentStartMonth) % 12 === 0) {
        prepaymentForMonth = prepaymentAmount;
      }
    }

    // Determine regular EMI payment
    let emiForMonth = currentEMI;

    // If remaining principal + interest is less than regular EMI:
    if (openingBalance + interestForMonth <= emiForMonth) {
      emiForMonth = openingBalance + interestForMonth;
      prepaymentForMonth = 0; // No extra prepayment needed
    }

    const principalFromEMI = Math.max(0, emiForMonth - interestForMonth);

    // If prepayment is greater than remaining balance after EMI:
    const remainingAfterEMI = Math.max(0, openingBalance - principalFromEMI);
    if (prepaymentForMonth > remainingAfterEMI) {
      prepaymentForMonth = remainingAfterEMI;
    }

    const totalPrincipalPaid = principalFromEMI + prepaymentForMonth;
    const closingBalance = Math.max(0, openingBalance - totalPrincipalPaid);

    totalInterest += interestForMonth;
    totalPayment += (emiForMonth + prepaymentForMonth);
    totalPrepayment += prepaymentForMonth;

    const cumulativePaidPrincipal = principal - closingBalance;
    const progressPercent = Math.min(100, (cumulativePaidPrincipal / principal) * 100);

    const yearIndex = Math.ceil(monthIndex / 12);
    const monthInYear = ((monthIndex - 1) % 12) + 1;

    monthlySchedule.push({
      monthIndex,
      yearIndex,
      monthInYear,
      dateLabel: dateInfo.label,
      openingBalance,
      emi: emiForMonth,
      interest: interestForMonth,
      principal: principalFromEMI,
      prepayment: prepaymentForMonth,
      totalMonthlyPaid: emiForMonth + prepaymentForMonth,
      closingBalance,
      loanProgressPercent: progressPercent,
    });

    currentBalance = closingBalance;

    // If user chose to reduce EMI instead of tenure and a prepayment occurred:
    if (applyPrepayment && inputs.hasPrepayment && prepaymentForMonth > 0 && prepaymentTarget === 'reduce-emi' && currentBalance > 0.5) {
      const remainingMonths = Math.max(1, tenureMonths - monthIndex);
      currentEMI = calculateEMI(currentBalance, interestRate, remainingMonths);
    }
  }

  // Construct yearly aggregation
  const yearlyMap = new Map<number, YearlyScheduleItem>();
  for (const item of monthlySchedule) {
    if (!yearlyMap.has(item.yearIndex)) {
      yearlyMap.set(item.yearIndex, {
        yearIndex: item.yearIndex,
        yearLabel: `Year ${item.yearIndex}`,
        openingBalance: item.openingBalance,
        totalEMI: 0,
        totalPrincipal: 0,
        totalInterest: 0,
        totalPrepayment: 0,
        totalPaid: 0,
        closingBalance: item.closingBalance,
        months: [],
      });
    }
    const yearItem = yearlyMap.get(item.yearIndex)!;
    yearItem.totalEMI += item.emi;
    yearItem.totalPrincipal += item.principal;
    yearItem.totalInterest += item.interest;
    yearItem.totalPrepayment += item.prepayment;
    yearItem.totalPaid += item.totalMonthlyPaid;
    yearItem.closingBalance = item.closingBalance;
    yearItem.months.push(item);
  }

  const yearlySchedule = Array.from(yearlyMap.values());
  const payoffDate = monthlySchedule.length > 0
    ? monthlySchedule[monthlySchedule.length - 1].dateLabel
    : '';

  return {
    monthlySchedule,
    yearlySchedule,
    totalInterest,
    totalPayment,
    totalPrepayment,
    monthsCount: monthlySchedule.length,
    payoffDate,
  };
}

/**
 * Calculates complete loan data including baseline comparison and prepayment savings.
 */
export function calculateFullLoan(inputs: LoanInputs): LoanCalculationResult {
  // Baseline (without prepayment)
  const baseSim = simulateSchedule(inputs, false);
  const baseEMI = calculateEMI(inputs.principal, inputs.interestRate, inputs.tenureMonths);

  // Actual (with prepayment if enabled)
  const actualSim = simulateSchedule(inputs, inputs.hasPrepayment);

  const interestSaved = Math.max(0, baseSim.totalInterest - actualSim.totalInterest);
  const interestSavedPercent = baseSim.totalInterest > 0
    ? (interestSaved / baseSim.totalInterest) * 100
    : 0;

  const tenureMonthsSaved = Math.max(0, baseSim.monthsCount - actualSim.monthsCount);
  const tenureYearsSaved = +(tenureMonthsSaved / 12).toFixed(1);

  const totalActual = actualSim.totalPayment;
  const principalRatio = totalActual > 0 ? (inputs.principal / totalActual) * 100 : 100;
  const interestRatio = totalActual > 0 ? (actualSim.totalInterest / totalActual) * 100 : 0;

  return {
    baseEMI,
    baseTotalInterest: baseSim.totalInterest,
    baseTotalPayment: baseSim.totalPayment,
    baseTenureMonths: baseSim.monthsCount,
    basePayoffDate: baseSim.payoffDate,

    actualEMI: baseEMI,
    actualTotalInterest: actualSim.totalInterest,
    actualTotalPayment: actualSim.totalPayment,
    actualTenureMonths: actualSim.monthsCount,
    actualPayoffDate: actualSim.payoffDate,
    totalPrepaymentPaid: actualSim.totalPrepayment,

    interestSaved,
    interestSavedPercent,
    tenureMonthsSaved,
    tenureYearsSaved,

    principalRatio,
    interestRatio,

    monthlySchedule: actualSim.monthlySchedule,
    yearlySchedule: actualSim.yearlySchedule,
    baseMonthlySchedule: baseSim.monthlySchedule,
  };
}

/**
 * Formats a number to Indian Rupee currency format (e.g. ₹ 25,00,000)
 */
export function formatINR(val: number, options?: { maximumFractionDigits?: number; compact?: boolean }): string {
  if (isNaN(val) || val === null || val === undefined) return '₹0';
  const digits = options?.maximumFractionDigits ?? 0;

  if (options?.compact) {
    if (Math.abs(val) >= 10000000) {
      return `₹${(val / 10000000).toFixed(2)} Cr`;
    }
    if (Math.abs(val) >= 100000) {
      return `₹${(val / 100000).toFixed(2)} L`;
    }
    if (Math.abs(val) >= 1000) {
      return `₹${(val / 1000).toFixed(1)} K`;
    }
  }

  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: digits,
  }).format(val);
}

/**
 * Converts a rupee number into Indian verbal words (e.g., "25 Lakhs", "1.50 Crore")
 */
export function numberToIndianWords(amount: number): string {
  if (amount <= 0) return 'Zero';
  if (amount >= 10000000) {
    const cr = amount / 10000000;
    return `${cr.toFixed(2).replace(/\.00$/, '')} Crore${cr > 1 ? 's' : ''}`;
  }
  if (amount >= 100000) {
    const lakh = amount / 100000;
    return `${lakh.toFixed(2).replace(/\.00$/, '')} Lakh${lakh > 1 ? 's' : ''}`;
  }
  if (amount >= 1000) {
    const k = amount / 1000;
    return `${k.toFixed(1).replace(/\.0$/, '')} Thousand`;
  }
  return amount.toLocaleString('en-IN');
}
