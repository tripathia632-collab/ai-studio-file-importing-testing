import React from 'react';
import { IndianRupee, Sparkles, TrendingDown, Clock, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { LoanInputs, LoanCalculationResult } from '../types/loan';
import { formatINR } from '../utils/loanCalculations';

interface LoanSummaryCardsProps {
  inputs: LoanInputs;
  result: LoanCalculationResult;
}

export const LoanSummaryCards: React.FC<LoanSummaryCardsProps> = ({ inputs, result }) => {
  const isPrepaymentActive = inputs.hasPrepayment && inputs.prepaymentAmount > 0;
  const hasSavings = isPrepaymentActive && result.interestSaved > 0;

  return (
    <div className="flex flex-col gap-5">
      {/* 4 Core Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Monthly EMI */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 mb-2">
              <span>Monthly EMI</span>
              <span className="text-slate-400 font-normal">Per Month</span>
            </div>
            <div className="text-2xl font-bold text-slate-900 font-mono tracking-tight tabular-nums">
              {formatINR(Math.round(result.actualEMI))}
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Tenure:</span>
            <span className="font-medium text-slate-700">
              {result.actualTenureMonths} Months ({+(result.actualTenureMonths / 12).toFixed(1)} Yrs)
            </span>
          </div>
        </div>

        {/* Card 2: Total Interest */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 mb-2">
              <span>Total Interest</span>
              <span className="text-amber-600 font-medium">
                {result.interestRatio.toFixed(1)}% of total
              </span>
            </div>
            <div className="text-2xl font-bold text-amber-600 font-mono tracking-tight tabular-nums">
              {formatINR(Math.round(result.actualTotalInterest))}
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Interest Rate:</span>
            <span className="font-medium text-slate-700 font-mono">{inputs.interestRate}% p.a.</span>
          </div>
        </div>

        {/* Card 3: Total Payment */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 mb-2">
              <span>Total Payment</span>
              <span className="text-slate-400 font-normal">Principal + Interest</span>
            </div>
            <div className="text-2xl font-bold text-slate-900 font-mono tracking-tight tabular-nums">
              {formatINR(Math.round(result.actualTotalPayment))}
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Principal:</span>
            <span className="font-medium text-slate-700 font-mono">{formatINR(inputs.principal)}</span>
          </div>
        </div>

        {/* Card 4: Payoff Date */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 mb-2">
              <span>Loan Payoff Date</span>
              <span className="text-slate-400 font-normal">Completion</span>
            </div>
            <div className="text-2xl font-bold text-blue-600 tracking-tight">
              {result.actualPayoffDate || '—'}
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Original Payoff:</span>
            <span className="font-medium text-slate-700">{result.basePayoffDate}</span>
          </div>
        </div>
      </div>

      {/* Prepayment Impact Banner & Comparison (When Prepayment Active) */}
      {isPrepaymentActive && (
        <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-5 shadow-xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-emerald-100">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs font-bold text-emerald-800 tracking-wide uppercase">
                  Prepayment Savings Unlocked
                </div>
                <div className="text-2xl sm:text-3xl font-extrabold text-emerald-900 font-mono tabular-nums mt-0.5">
                  {formatINR(Math.round(result.interestSaved))} Saved!
                </div>
                <p className="text-xs text-emerald-700 mt-1">
                  You save{' '}
                  <span className="font-bold">{result.interestSavedPercent.toFixed(1)}%</span> of total interest
                  {result.tenureMonthsSaved > 0 && (
                    <span>
                      {' '}and clear your loan{' '}
                      <span className="font-bold">
                        {result.tenureMonthsSaved} months ({result.tenureYearsSaved} years) earlier
                      </span>
                    </span>
                  )}
                  .
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 self-start md:self-center">
              <div className="bg-white/90 border border-emerald-200 px-3.5 py-2 rounded-lg text-center">
                <div className="text-[10px] font-semibold text-slate-500 uppercase">Tenure Saved</div>
                <div className="text-base font-bold text-emerald-700 font-mono tabular-nums">
                  {result.tenureMonthsSaved} Mos
                </div>
              </div>
              <div className="bg-white/90 border border-emerald-200 px-3.5 py-2 rounded-lg text-center">
                <div className="text-[10px] font-semibold text-slate-500 uppercase">Interest Cut</div>
                <div className="text-base font-bold text-emerald-700 font-mono tabular-nums">
                  {result.interestSavedPercent.toFixed(0)}%
                </div>
              </div>
            </div>
          </div>

          {/* Side-by-side comparison table */}
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-emerald-200 text-slate-600 font-semibold">
                  <th className="py-2 pr-4">Metric</th>
                  <th className="py-2 px-4">Without Prepayment</th>
                  <th className="py-2 px-4 text-emerald-900 font-bold bg-emerald-100/60 rounded-t">
                    With Prepayment
                  </th>
                  <th className="py-2 pl-4 text-right">Net Difference</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-emerald-100/70 text-slate-700 font-medium">
                <tr>
                  <td className="py-2 pr-4 text-slate-500">Monthly EMI</td>
                  <td className="py-2 px-4 font-mono tabular-nums">{formatINR(Math.round(result.baseEMI))}</td>
                  <td className="py-2 px-4 font-mono font-semibold text-emerald-900 bg-emerald-100/40 tabular-nums">
                    {formatINR(Math.round(result.actualEMI))}
                  </td>
                  <td className="py-2 pl-4 text-right font-mono text-slate-500 tabular-nums">
                    {inputs.prepaymentTarget === 'reduce-emi'
                      ? `-${formatINR(Math.round(result.baseEMI - result.actualEMI))}`
                      : 'Unchanged'}
                  </td>
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-slate-500">Total Interest</td>
                  <td className="py-2 px-4 font-mono tabular-nums">{formatINR(Math.round(result.baseTotalInterest))}</td>
                  <td className="py-2 px-4 font-mono font-semibold text-emerald-900 bg-emerald-100/40 tabular-nums">
                    {formatINR(Math.round(result.actualTotalInterest))}
                  </td>
                  <td className="py-2 pl-4 text-right font-mono font-bold text-emerald-700 tabular-nums">
                    -{formatINR(Math.round(result.interestSaved))}
                  </td>
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-slate-500">Total Outflow</td>
                  <td className="py-2 px-4 font-mono tabular-nums">{formatINR(Math.round(result.baseTotalPayment))}</td>
                  <td className="py-2 px-4 font-mono font-semibold text-emerald-900 bg-emerald-100/40 tabular-nums">
                    {formatINR(Math.round(result.actualTotalPayment))}
                  </td>
                  <td className="py-2 pl-4 text-right font-mono font-bold text-emerald-700 tabular-nums">
                    -{formatINR(Math.round(result.baseTotalPayment - result.actualTotalPayment))}
                  </td>
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-slate-500">Loan Tenure</td>
                  <td className="py-2 px-4">{result.baseTenureMonths} Months ({+(result.baseTenureMonths / 12).toFixed(1)} yrs)</td>
                  <td className="py-2 px-4 font-semibold text-emerald-900 bg-emerald-100/40">
                    {result.actualTenureMonths} Months ({+(result.actualTenureMonths / 12).toFixed(1)} yrs)
                  </td>
                  <td className="py-2 pl-4 text-right font-mono font-bold text-emerald-700 tabular-nums">
                    {result.tenureMonthsSaved > 0 ? `-${result.tenureMonthsSaved} Months` : '0'}
                  </td>
                </tr>
                <tr>
                  <td className="py-2 pr-4 text-slate-500">Payoff Date</td>
                  <td className="py-2 px-4">{result.basePayoffDate}</td>
                  <td className="py-2 px-4 font-semibold text-emerald-900 bg-emerald-100/40">
                    {result.actualPayoffDate}
                  </td>
                  <td className="py-2 pl-4 text-right font-medium text-emerald-700">
                    {result.tenureMonthsSaved > 0 ? 'Finishes Early' : 'Same'}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
