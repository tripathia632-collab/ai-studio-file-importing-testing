import React from 'react';
import { IndianRupee, Printer, Download, Sparkles } from 'lucide-react';

interface HeaderProps {
  onPrint: () => void;
  onDownloadCSV: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onPrint, onDownloadCSV }) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Wordmark */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-500/20">
            <IndianRupee className="w-5 h-5 stroke-[2.25]" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold tracking-tight text-slate-900 leading-none">
              RupeeLoan
            </span>
            <span className="text-[11px] font-medium text-slate-500 tracking-wide">
              EMI & Prepayment Calculator
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
          <a
            href="#calculator-section"
            className="hover:text-blue-600 transition-colors whitespace-nowrap"
          >
            Calculator
          </a>
          <a
            href="#summary-section"
            className="hover:text-blue-600 transition-colors whitespace-nowrap"
          >
            Summary & Savings
          </a>
          <a
            href="#charts-section"
            className="hover:text-blue-600 transition-colors whitespace-nowrap"
          >
            Breakdown Chart
          </a>
          <a
            href="#schedule-section"
            className="hover:text-blue-600 transition-colors whitespace-nowrap"
          >
            Amortization Schedule
          </a>
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={onDownloadCSV}
            title="Download Amortization Schedule CSV"
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 hover:text-slate-900 rounded-lg transition-colors whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>
          <button
            onClick={onPrint}
            title="Print or Save Official Loan Schedule as PDF"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg shadow-sm shadow-blue-600/20 transition-all whitespace-nowrap"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / PDF</span>
          </button>
        </div>
      </div>
    </header>
  );
};
