import React, { useState, useMemo } from 'react';
import {
  Calendar,
  ChevronDown,
  ChevronRight,
  Download,
  Printer,
  Search,
  Filter,
  CheckCircle2,
  ArrowUpDown,
  Sparkles,
} from 'lucide-react';
import {
  LoanInputs,
  LoanCalculationResult,
  MonthlyScheduleItem,
  YearlyScheduleItem,
} from '../types/loan';
import { formatINR } from '../utils/loanCalculations';

interface AmortizationScheduleProps {
  inputs: LoanInputs;
  result: LoanCalculationResult;
  onDownloadCSV: () => void;
  onPrint: () => void;
}

export const AmortizationSchedule: React.FC<AmortizationScheduleProps> = ({
  inputs,
  result,
  onDownloadCSV,
  onPrint,
}) => {
  const [viewMode, setViewMode] = useState<'yearly-accordion' | 'all-months'>('yearly-accordion');
  const [expandedYears, setExpandedYears] = useState<Set<number>>(new Set([1])); // Year 1 expanded by default
  const [filterOnlyPrepayments, setFilterOnlyPrepayments] = useState(false);
  const [selectedYearFilter, setSelectedYearFilter] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 24;

  const toggleYear = (yearIndex: number) => {
    setExpandedYears((prev) => {
      const next = new Set(prev);
      if (next.has(yearIndex)) {
        next.delete(yearIndex);
      } else {
        next.add(yearIndex);
      }
      return next;
    });
  };

  const expandAllYears = () => {
    const all = new Set(result.yearlySchedule.map((y) => y.yearIndex));
    setExpandedYears(all);
  };

  const collapseAllYears = () => {
    setExpandedYears(new Set());
  };

  // Filtered monthly items for "all-months" view
  const filteredMonths = useMemo(() => {
    let list = result.monthlySchedule;

    if (filterOnlyPrepayments) {
      list = list.filter((m) => m.prepayment > 0);
    }

    if (selectedYearFilter !== 'all') {
      const targetYear = parseInt(selectedYearFilter, 10);
      list = list.filter((m) => m.yearIndex === targetYear);
    }

    return list;
  }, [result.monthlySchedule, filterOnlyPrepayments, selectedYearFilter]);

  // Paginated months for "all-months" view
  const totalPages = Math.ceil(filteredMonths.length / rowsPerPage) || 1;
  const paginatedMonths = useMemo(() => {
    const start = (currentPage - 1) * rowsPerPage;
    return filteredMonths.slice(start, start + rowsPerPage);
  }, [filteredMonths, currentPage, rowsPerPage]);

  return (
    <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden flex flex-col">
      {/* Table Header & Controls Bar */}
      <div className="p-5 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <span>Month-wise Amortization Schedule</span>
            <span className="text-xs font-normal text-slate-500 font-mono">
              ({result.actualTenureMonths} installments)
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Exact breakdown of Opening Balance, EMI, Interest, Principal, and Closing Balance
          </p>
        </div>

        {/* Action Controls */}
        <div id="export-toolbar" className="flex flex-wrap items-center gap-2 self-start md:self-auto">
          {/* Mode Switcher */}
          <div className="flex items-center p-0.5 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setViewMode('yearly-accordion')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${
                viewMode === 'yearly-accordion'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Yearly Groups
            </button>
            <button
              type="button"
              onClick={() => setViewMode('all-months')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${
                viewMode === 'all-months'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Months ({result.actualTenureMonths})
            </button>
          </div>

          {/* Quick Download & Print */}
          <button
            onClick={onDownloadCSV}
            title="Download CSV"
            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={onPrint}
            title="Print Statement"
            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors"
          >
            <Printer className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="px-5 py-3 bg-slate-50/70 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          {/* Year Filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-medium">Filter Year:</span>
            <select
              value={selectedYearFilter}
              onChange={(e) => {
                setSelectedYearFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-white border border-slate-200 text-slate-800 rounded-md px-2 py-1 text-xs font-medium focus:outline-none focus:border-blue-500"
            >
              <option value="all">All Years ({result.yearlySchedule.length})</option>
              {result.yearlySchedule.map((y) => (
                <option key={y.yearIndex} value={y.yearIndex}>
                  Year {y.yearIndex}
                </option>
              ))}
            </select>
          </div>

          {/* Prepayment Filter checkbox */}
          {inputs.hasPrepayment && (
            <label className="flex items-center gap-1.5 cursor-pointer text-slate-700">
              <input
                type="checkbox"
                checked={filterOnlyPrepayments}
                onChange={(e) => {
                  setFilterOnlyPrepayments(e.target.checked);
                  setCurrentPage(1);
                }}
                className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500/20"
              />
              <span className="font-medium text-emerald-800">Only Prepayment Months</span>
            </label>
          )}
        </div>

        {viewMode === 'yearly-accordion' && (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={expandAllYears}
              className="text-slate-600 hover:text-slate-900 font-medium hover:underline text-xs"
            >
              Expand All
            </button>
            <span className="text-slate-300">·</span>
            <button
              type="button"
              onClick={collapseAllYears}
              className="text-slate-600 hover:text-slate-900 font-medium hover:underline text-xs"
            >
              Collapse All
            </button>
          </div>
        )}
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-100/80 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider text-[11px]">
              <th className="py-3 px-4">Month / Date</th>
              <th className="py-3 px-4 text-right">Opening Balance</th>
              <th className="py-3 px-4 text-right">EMI (₹)</th>
              <th className="py-3 px-4 text-right">Interest (₹)</th>
              <th className="py-3 px-4 text-right">Principal (₹)</th>
              {inputs.hasPrepayment && (
                <th className="py-3 px-4 text-right text-emerald-800">Prepayment (₹)</th>
              )}
              <th className="py-3 px-4 text-right">Closing Balance</th>
              <th className="py-3 px-4 text-right">Paid Off</th>
            </tr>
          </thead>

          {/* 1. Yearly Accordion Mode */}
          {viewMode === 'yearly-accordion' && (
            <tbody className="divide-y divide-slate-100">
              {result.yearlySchedule
                .filter((y) => selectedYearFilter === 'all' || y.yearIndex === parseInt(selectedYearFilter, 10))
                .map((yearItem) => {
                  const isExpanded = expandedYears.has(yearItem.yearIndex);
                  const hasYearPrepayment = yearItem.totalPrepayment > 0;

                  return (
                    <React.Fragment key={yearItem.yearIndex}>
                      {/* Yearly Header Row */}
                      <tr
                        onClick={() => toggleYear(yearItem.yearIndex)}
                        className="bg-slate-50/90 hover:bg-slate-100/90 cursor-pointer font-bold text-slate-900 transition-colors select-none"
                      >
                        <td className="py-3 px-4 flex items-center gap-2">
                          <span className="text-slate-400">
                            {isExpanded ? (
                              <ChevronDown className="w-4 h-4 text-blue-600" />
                            ) : (
                              <ChevronRight className="w-4 h-4" />
                            )}
                          </span>
                          <span>{yearItem.yearLabel}</span>
                          <span className="text-[11px] font-normal text-slate-500 font-mono">
                            ({yearItem.months.length} months)
                          </span>
                          {hasYearPrepayment && (
                            <span className="ml-1 text-[10px] font-semibold text-emerald-800 bg-emerald-100/80 px-1.5 py-0.5 rounded">
                              Prepaid
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums">
                          {formatINR(Math.round(yearItem.openingBalance))}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums">
                          {formatINR(Math.round(yearItem.totalEMI))}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-amber-700">
                          {formatINR(Math.round(yearItem.totalInterest))}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-blue-700">
                          {formatINR(Math.round(yearItem.totalPrincipal))}
                        </td>
                        {inputs.hasPrepayment && (
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-700">
                            {yearItem.totalPrepayment > 0
                              ? formatINR(Math.round(yearItem.totalPrepayment))
                              : '—'}
                          </td>
                        )}
                        <td className="py-3 px-4 text-right font-mono tabular-nums">
                          {formatINR(Math.round(yearItem.closingBalance))}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-500">
                          {yearItem.months[yearItem.months.length - 1]?.loanProgressPercent.toFixed(1)}%
                        </td>
                      </tr>

                      {/* Month Rows inside expanded Year */}
                      {isExpanded &&
                        yearItem.months.map((m) => (
                          <tr
                            key={m.monthIndex}
                            className={`hover:bg-blue-50/40 transition-colors ${
                              m.prepayment > 0 ? 'bg-emerald-50/50' : 'bg-white'
                            }`}
                          >
                            <td className="py-2.5 px-4 pl-9 text-slate-700">
                              <span className="font-medium">M{m.monthIndex}</span>{' '}
                              <span className="text-slate-400 font-mono text-[11px]">
                                · {m.dateLabel}
                              </span>
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-600">
                              {formatINR(Math.round(m.openingBalance))}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono tabular-nums font-medium text-slate-900">
                              {formatINR(Math.round(m.emi))}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono tabular-nums text-amber-600">
                              {formatINR(Math.round(m.interest))}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono tabular-nums text-blue-600 font-medium">
                              {formatINR(Math.round(m.principal))}
                            </td>
                            {inputs.hasPrepayment && (
                              <td className="py-2.5 px-4 text-right font-mono tabular-nums">
                                {m.prepayment > 0 ? (
                                  <span className="font-semibold text-emerald-700 bg-emerald-100/70 px-1.5 py-0.5 rounded text-[11px]">
                                    +{formatINR(Math.round(m.prepayment))}
                                  </span>
                                ) : (
                                  <span className="text-slate-300">—</span>
                                )}
                              </td>
                            )}
                            <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-800">
                              {formatINR(Math.round(m.closingBalance))}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-500">
                              <div className="flex items-center justify-end gap-1.5">
                                <span>{m.loanProgressPercent.toFixed(1)}%</span>
                                <div className="w-10 bg-slate-100 h-1.5 rounded-full overflow-hidden shrink-0">
                                  <div
                                    className="bg-blue-600 h-full rounded-full"
                                    style={{ width: `${m.loanProgressPercent}%` }}
                                  ></div>
                                </div>
                              </div>
                            </td>
                          </tr>
                        ))}
                    </React.Fragment>
                  );
                })}
            </tbody>
          )}

          {/* 2. All Months Continuous View */}
          {viewMode === 'all-months' && (
            <tbody className="divide-y divide-slate-100">
              {paginatedMonths.map((m) => (
                <tr
                  key={m.monthIndex}
                  className={`hover:bg-blue-50/40 transition-colors ${
                    m.prepayment > 0 ? 'bg-emerald-50/50' : 'bg-white'
                  }`}
                >
                  <td className="py-2.5 px-4 text-slate-700">
                    <span className="font-bold text-slate-900">M{m.monthIndex}</span>{' '}
                    <span className="text-slate-400 font-mono text-[11px]">· {m.dateLabel}</span>
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-600">
                    {formatINR(Math.round(m.openingBalance))}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono tabular-nums font-semibold text-slate-900">
                    {formatINR(Math.round(m.emi))}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono tabular-nums text-amber-600">
                    {formatINR(Math.round(m.interest))}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono tabular-nums text-blue-600 font-semibold">
                    {formatINR(Math.round(m.principal))}
                  </td>
                  {inputs.hasPrepayment && (
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums">
                      {m.prepayment > 0 ? (
                        <span className="font-semibold text-emerald-700 bg-emerald-100/70 px-1.5 py-0.5 rounded text-[11px]">
                          +{formatINR(Math.round(m.prepayment))}
                        </span>
                      ) : (
                        <span className="text-slate-300">—</span>
                      )}
                    </td>
                  )}
                  <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-800">
                    {formatINR(Math.round(m.closingBalance))}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-500">
                    <div className="flex items-center justify-end gap-1.5">
                      <span>{m.loanProgressPercent.toFixed(1)}%</span>
                      <div className="w-12 bg-slate-100 h-1.5 rounded-full overflow-hidden shrink-0">
                        <div
                          className="bg-blue-600 h-full rounded-full"
                          style={{ width: `${m.loanProgressPercent}%` }}
                        ></div>
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          )}

          {/* Table Footer Totals */}
          <tfoot>
            <tr className="bg-slate-100 border-t-2 border-slate-300 font-bold text-slate-900 text-xs">
              <td className="py-3 px-4">TOTALS</td>
              <td className="py-3 px-4 text-right text-slate-400 font-mono">—</td>
              <td className="py-3 px-4 text-right font-mono tabular-nums">
                {formatINR(Math.round(result.actualTotalPayment - result.totalPrepaymentPaid))}
              </td>
              <td className="py-3 px-4 text-right font-mono tabular-nums text-amber-700">
                {formatINR(Math.round(result.actualTotalInterest))}
              </td>
              <td className="py-3 px-4 text-right font-mono tabular-nums text-blue-700">
                {formatINR(inputs.principal)}
              </td>
              {inputs.hasPrepayment && (
                <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-700">
                  {result.totalPrepaymentPaid > 0
                    ? formatINR(Math.round(result.totalPrepaymentPaid))
                    : '—'}
                </td>
              )}
              <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-900">
                ₹0
              </td>
              <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-700">
                100%
              </td>
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Pagination Bar for All Months View */}
      {viewMode === 'all-months' && totalPages > 1 && (
        <div className="px-5 py-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-600 bg-slate-50">
          <span>
            Showing {(currentPage - 1) * rowsPerPage + 1}–
            {Math.min(currentPage * rowsPerPage, filteredMonths.length)} of {filteredMonths.length} installments
          </span>
          <div className="flex items-center gap-1">
            <button
              type="button"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              className="px-2.5 py-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            <span className="px-2 font-mono text-slate-700">
              Page {currentPage} of {totalPages}
            </span>
            <button
              type="button"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              className="px-2.5 py-1 rounded bg-white border border-slate-200 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
