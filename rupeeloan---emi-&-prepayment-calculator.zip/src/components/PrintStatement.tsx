import React from 'react';
import { LoanInputs, LoanCalculationResult } from '../types/loan';
import { formatINR } from '../utils/loanCalculations';

interface PrintStatementProps {
  inputs: LoanInputs;
  result: LoanCalculationResult;
}

export const PrintStatement: React.FC<PrintStatementProps> = ({ inputs, result }) => {
  const currentDate = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  return (
    <div className="hidden print-only mb-6 border-b-2 border-slate-900 pb-4">
      {/* Print Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-xl font-bold text-slate-900 uppercase tracking-tight">
            Loan Amortization & Repayment Statement
          </h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Generated on {currentDate} · Official Repayment Schedule & Prepayment Forecast
          </p>
        </div>
        <div className="text-right">
          <div className="text-sm font-bold text-slate-900 font-mono">RupeeLoan Calculator</div>
          <div className="text-[10px] text-slate-500">Ref: RL-{Date.now().toString().slice(-6)}</div>
        </div>
      </div>

      {/* Parameter Summary Grid */}
      <div className="mt-4 grid grid-cols-4 gap-2 text-xs border border-slate-300 p-3 bg-slate-50">
        <div>
          <span className="text-slate-500 block text-[10px] uppercase">Loan Amount</span>
          <span className="font-bold text-slate-900 font-mono">{formatINR(inputs.principal)}</span>
        </div>
        <div>
          <span className="text-slate-500 block text-[10px] uppercase">Interest Rate</span>
          <span className="font-bold text-slate-900 font-mono">{inputs.interestRate}% p.a.</span>
        </div>
        <div>
          <span className="text-slate-500 block text-[10px] uppercase">Monthly EMI</span>
          <span className="font-bold text-slate-900 font-mono">{formatINR(Math.round(result.actualEMI))}</span>
        </div>
        <div>
          <span className="text-slate-500 block text-[10px] uppercase">Loan Tenure</span>
          <span className="font-bold text-slate-900">{inputs.tenureYears} Yrs ({result.actualTenureMonths} Mos)</span>
        </div>
        <div className="mt-2">
          <span className="text-slate-500 block text-[10px] uppercase">Total Interest</span>
          <span className="font-bold text-slate-900 font-mono">{formatINR(Math.round(result.actualTotalInterest))}</span>
        </div>
        <div className="mt-2">
          <span className="text-slate-500 block text-[10px] uppercase">Total Outflow</span>
          <span className="font-bold text-slate-900 font-mono">{formatINR(Math.round(result.actualTotalPayment))}</span>
        </div>
        <div className="mt-2">
          <span className="text-slate-500 block text-[10px] uppercase">Payoff Date</span>
          <span className="font-bold text-slate-900">{result.actualPayoffDate}</span>
        </div>
        {inputs.hasPrepayment && (
          <div className="mt-2">
            <span className="text-slate-500 block text-[10px] uppercase">Interest Saved</span>
            <span className="font-bold text-emerald-800 font-mono">{formatINR(Math.round(result.interestSaved))}</span>
          </div>
        )}
      </div>
    </div>
  );
};
