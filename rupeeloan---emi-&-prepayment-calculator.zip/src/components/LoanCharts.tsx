import React, { useState } from 'react';
import { PieChart, BarChart3, TrendingDown, Info } from 'lucide-react';
import { LoanInputs, LoanCalculationResult, YearlyScheduleItem } from '../types/loan';
import { formatINR } from '../utils/loanCalculations';

interface LoanChartsProps {
  inputs: LoanInputs;
  result: LoanCalculationResult;
}

export const LoanCharts: React.FC<LoanChartsProps> = ({ inputs, result }) => {
  const [activeTab, setActiveTab] = useState<'donut' | 'amortization'>('donut');
  const [hoveredYear, setHoveredYear] = useState<YearlyScheduleItem | null>(null);
  const [mousePos, setMousePos] = useState<{ x: number; y: number } | null>(null);

  // Donut chart calculations
  const totalAmount = result.actualTotalPayment || 1;
  const principalAmount = inputs.principal;
  const interestAmount = result.actualTotalInterest;

  const principalPercent = (principalAmount / totalAmount) * 100;
  const interestPercent = (interestAmount / totalAmount) * 100;

  // SVG Donut metrics
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const principalStroke = (principalPercent / 100) * circumference;
  const interestStroke = (interestPercent / 100) * circumference;
  const principalOffset = 0;
  const interestOffset = -principalStroke;

  // Yearly data for Amortization Chart
  const yearlyData = result.yearlySchedule;
  const maxYearlyPayment = Math.max(
    ...yearlyData.map((y) => y.totalPrincipal + y.totalInterest),
    1
  );

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-xs flex flex-col gap-5">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div>
          <h2 className="text-base font-bold text-slate-900 tracking-tight">
            Principal & Interest Analysis
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Visualize the split of your money between loan recovery and interest cost
          </p>
        </div>

        {/* View Switcher */}
        <div id="chart-tabs" className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setActiveTab('donut')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${
              activeTab === 'donut'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <PieChart className="w-3.5 h-3.5" />
            <span>Breakdown Ratio</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('amortization')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md transition-all ${
              activeTab === 'amortization'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Yearly Trajectory</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Donut Chart View */}
      {activeTab === 'donut' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center py-2">
          {/* Donut SVG */}
          <div className="md:col-span-6 flex flex-col items-center justify-center relative">
            <svg
              viewBox="0 0 200 200"
              className="w-56 h-56 transform -rotate-90 drop-shadow-xs"
            >
              {/* Background circle track */}
              <circle
                cx="100"
                cy="100"
                r={radius}
                className="stroke-slate-100"
                strokeWidth="24"
                fill="transparent"
              />
              {/* Principal Segment */}
              <circle
                cx="100"
                cy="100"
                r={radius}
                className="stroke-blue-600 transition-all duration-500 ease-out"
                strokeWidth="24"
                strokeDasharray={`${principalStroke} ${circumference}`}
                strokeDashoffset={principalOffset}
                strokeLinecap="butt"
                fill="transparent"
              />
              {/* Interest Segment */}
              <circle
                cx="100"
                cy="100"
                r={radius}
                className="stroke-amber-500 transition-all duration-500 ease-out"
                strokeWidth="24"
                strokeDasharray={`${interestStroke} ${circumference}`}
                strokeDashoffset={interestOffset}
                strokeLinecap="butt"
                fill="transparent"
              />
            </svg>

            {/* Inner Center Label */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center px-4">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Total Payable
              </span>
              <span className="text-lg sm:text-xl font-bold text-slate-900 font-mono tabular-nums leading-tight">
                {formatINR(Math.round(result.actualTotalPayment), { compact: true })}
              </span>
              <span className="text-[11px] text-slate-500 font-medium">
                {result.actualTenureMonths} Mos
              </span>
            </div>
          </div>

          {/* Breakdown Legend & Detailed Metrics */}
          <div className="md:col-span-6 flex flex-col gap-4">
            {/* Principal row */}
            <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded bg-blue-600 shrink-0"></span>
                  <span className="text-xs font-bold text-slate-800">Principal Loan Amount</span>
                </div>
                <span className="text-xs font-bold text-blue-600 font-mono tabular-nums">
                  {principalPercent.toFixed(1)}%
                </span>
              </div>
              <div className="text-lg font-bold text-slate-900 font-mono tabular-nums mt-1">
                {formatINR(inputs.principal)}
              </div>
              <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mt-2">
                <div
                  className="bg-blue-600 h-full rounded-full transition-all duration-500"
                  style={{ width: `${principalPercent}%` }}
                ></div>
              </div>
            </div>

            {/* Interest row */}
            <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded bg-amber-500 shrink-0"></span>
                  <span className="text-xs font-bold text-slate-800">Total Interest Amount</span>
                </div>
                <span className="text-xs font-bold text-amber-600 font-mono tabular-nums">
                  {interestPercent.toFixed(1)}%
                </span>
              </div>
              <div className="text-lg font-bold text-slate-900 font-mono tabular-nums mt-1">
                {formatINR(Math.round(result.actualTotalInterest))}
              </div>
              <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden mt-2">
                <div
                  className="bg-amber-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${interestPercent}%` }}
                ></div>
              </div>
            </div>

            {/* Prepayment Note if applied */}
            {inputs.hasPrepayment && result.interestSaved > 0 && (
              <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded bg-emerald-600 shrink-0"></span>
                  <span className="text-xs font-bold text-emerald-900">Interest Saved by Prepayment</span>
                </div>
                <span className="text-xs font-bold text-emerald-700 font-mono tabular-nums">
                  +{formatINR(Math.round(result.interestSaved))}
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Interactive Yearly Stacked Amortization Bar Chart */}
      {activeTab === 'amortization' && (
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-xs bg-blue-600"></span>
                <span>Principal Paid</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-xs bg-amber-500"></span>
                <span>Interest Paid</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3.5 h-0.5 bg-slate-700"></span>
                <span>Remaining Balance</span>
              </div>
            </div>
            <span className="text-[11px] text-slate-400">
              Hover on any year for detailed breakdown
            </span>
          </div>

          {/* Amortization Chart Container */}
          <div className="relative h-64 w-full pt-4 pb-6">
            <div className="flex items-end h-full gap-1.5 sm:gap-2 px-1">
              {yearlyData.map((yearItem) => {
                const totalYearPayment = yearItem.totalPrincipal + yearItem.totalInterest;
                const barHeightPercent = Math.min(100, (totalYearPayment / maxYearlyPayment) * 100);
                const principalRatioInBar = totalYearPayment > 0 ? (yearItem.totalPrincipal / totalYearPayment) : 0.5;
                const interestRatioInBar = 1 - principalRatioInBar;

                const isHovered = hoveredYear?.yearIndex === yearItem.yearIndex;

                return (
                  <div
                    key={yearItem.yearIndex}
                    className="flex-1 h-full flex flex-col justify-end items-center group cursor-pointer relative"
                    onMouseEnter={(e) => {
                      setHoveredYear(yearItem);
                      const rect = e.currentTarget.getBoundingClientRect();
                      setMousePos({ x: rect.left + rect.width / 2, y: rect.top });
                    }}
                    onMouseLeave={() => setHoveredYear(null)}
                  >
                    {/* The Stacked Bar */}
                    <div
                      className={`w-full max-w-[32px] rounded-t flex flex-col justify-end overflow-hidden transition-all duration-150 ${
                        isHovered ? 'ring-2 ring-blue-500 shadow-md scale-y-[1.02]' : 'opacity-90 group-hover:opacity-100'
                      }`}
                      style={{ height: `${Math.max(12, barHeightPercent)}%` }}
                    >
                      {/* Top: Interest (Amber) */}
                      <div
                        className="w-full bg-amber-500 transition-all"
                        style={{ height: `${interestRatioInBar * 100}%` }}
                      ></div>
                      {/* Bottom: Principal (Blue) */}
                      <div
                        className="w-full bg-blue-600 transition-all"
                        style={{ height: `${principalRatioInBar * 100}%` }}
                      ></div>
                    </div>

                    {/* Year Label */}
                    <span className="text-[10px] font-mono font-medium text-slate-500 mt-2 truncate w-full text-center">
                      Y{yearItem.yearIndex}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Hover Tooltip Box */}
            {hoveredYear && (
              <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-slate-900 text-white rounded-lg px-4 py-2.5 shadow-xl text-xs z-20 pointer-events-none flex flex-col gap-1 border border-slate-700 min-w-[210px]">
                <div className="font-bold text-slate-100 border-b border-slate-800 pb-1 flex justify-between">
                  <span>Year {hoveredYear.yearIndex}</span>
                  <span className="text-slate-400 font-mono">{hoveredYear.months[0]?.dateLabel}</span>
                </div>
                <div className="flex justify-between items-center text-slate-300">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                    Principal:
                  </span>
                  <span className="font-mono font-semibold text-white tabular-nums">
                    {formatINR(Math.round(hoveredYear.totalPrincipal))}
                  </span>
                </div>
                <div className="flex justify-between items-center text-slate-300">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                    Interest:
                  </span>
                  <span className="font-mono font-semibold text-white tabular-nums">
                    {formatINR(Math.round(hoveredYear.totalInterest))}
                  </span>
                </div>
                {hoveredYear.totalPrepayment > 0 && (
                  <div className="flex justify-between items-center text-emerald-300">
                    <span>Prepayment:</span>
                    <span className="font-mono font-semibold text-emerald-400 tabular-nums">
                      {formatINR(Math.round(hoveredYear.totalPrepayment))}
                    </span>
                  </div>
                )}
                <div className="flex justify-between items-center text-slate-400 border-t border-slate-800 pt-1 mt-0.5">
                  <span>Closing Balance:</span>
                  <span className="font-mono font-semibold text-slate-200 tabular-nums">
                    {formatINR(Math.round(hoveredYear.closingBalance))}
                  </span>
                </div>
              </div>
            )}
          </div>

          <div className="text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-lg border border-slate-100 flex items-center gap-2">
            <Info className="w-4 h-4 text-slate-400 shrink-0" />
            <span>
              Notice how early years consist mostly of Interest (Amber). As the principal reduces, the Principal repayment (Blue) expands until the loan is fully retired.
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
