import React, { useState } from 'react';
import { IndianRupee, Percent, Calendar, ShieldCheck, ChevronDown, ChevronUp, Zap, HelpCircle } from 'lucide-react';
import { LoanInputs, PrepaymentType, PrepaymentTarget } from '../types/loan';
import { numberToIndianWords } from '../utils/loanCalculations';

interface LoanInputsProps {
  inputs: LoanInputs;
  onChange: (newInputs: LoanInputs) => void;
}

export const LoanInputsPanel: React.FC<LoanInputsProps> = ({ inputs, onChange }) => {
  const [tenureUnit, setTenureUnit] = useState<'years' | 'months'>('years');
  const [showPrepaymentHelp, setShowPrepaymentHelp] = useState(false);

  const update = (partial: Partial<LoanInputs>) => {
    onChange({ ...inputs, ...partial });
  };

  const handlePrincipalChange = (val: number) => {
    const clamped = Math.max(10000, Math.min(500000000, isNaN(val) ? 0 : val));
    update({ principal: clamped });
  };

  const handleRateChange = (val: number) => {
    const clamped = Math.max(0.1, Math.min(30, isNaN(val) ? 0 : val));
    update({ interestRate: clamped });
  };

  const handleTenureYearsChange = (years: number) => {
    const clamped = Math.max(0.5, Math.min(35, isNaN(years) ? 1 : years));
    update({
      tenureYears: clamped,
      tenureMonths: Math.round(clamped * 12),
    });
  };

  const handleTenureMonthsChange = (months: number) => {
    const clamped = Math.max(6, Math.min(420, isNaN(months) ? 12 : months));
    update({
      tenureMonths: clamped,
      tenureYears: +(clamped / 12).toFixed(1),
    });
  };

  const loanPresets = [
    { label: 'Home Loan', rate: 8.5 },
    { label: 'Car Loan', rate: 9.2 },
    { label: 'Personal Loan', rate: 11.5 },
    { label: 'Education Loan', rate: 9.8 },
  ];

  const principalPresets = [
    { label: '₹10 Lakh', value: 1000000 },
    { label: '₹25 Lakh', value: 2500000 },
    { label: '₹50 Lakh', value: 5000000 },
    { label: '₹75 Lakh', value: 7500000 },
    { label: '₹1 Crore', value: 10000000 },
  ];

  const tenurePresets = [5, 10, 15, 20, 25, 30];

  const prepaymentPresets = [
    { label: '₹25,000', value: 25000 },
    { label: '₹50,000', value: 50000 },
    { label: '₹1 Lakh', value: 100000 },
    { label: '₹2 Lakh', value: 200000 },
    { label: '₹5 Lakh', value: 500000 },
  ];

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 shadow-xs flex flex-col gap-6">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div>
          <h2 className="text-base font-bold text-slate-900 tracking-tight">Loan Parameters</h2>
          <p className="text-xs text-slate-500 mt-0.5">Customize your loan terms to calculate EMI and schedule</p>
        </div>
      </div>

      {/* 1. Loan Amount */}
      <div className="flex flex-col gap-2.5">
        <div className="flex items-center justify-between">
          <label htmlFor="loan-amount-input" className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
            Loan Amount (Principal)
          </label>
          <span className="text-xs font-medium text-blue-600 tabular-nums">
            {numberToIndianWords(inputs.principal)}
          </span>
        </div>

        <div className="relative">
          <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-medium text-sm">
            ₹
          </span>
          <input
            id="loan-amount-input"
            type="number"
            min={10000}
            max={500000000}
            step={10000}
            value={inputs.principal || ''}
            onChange={(e) => handlePrincipalChange(parseFloat(e.target.value))}
            className="w-full pl-8 pr-4 py-2.5 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-blue-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 rounded-lg text-slate-900 font-mono text-base font-semibold tabular-nums transition-all"
          />
        </div>

        {/* Range Slider */}
        <input
          type="range"
          min={100000}
          max={20000000}
          step={50000}
          value={inputs.principal}
          onChange={(e) => handlePrincipalChange(parseFloat(e.target.value))}
          className="w-full mt-1"
        />

        <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
          <span>₹1 Lakh</span>
          <span>₹1 Crore</span>
          <span>₹2 Crore</span>
        </div>

        {/* Quick Amount Chips */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          {principalPresets.map((preset) => (
            <button
              key={preset.value}
              type="button"
              onClick={() => handlePrincipalChange(preset.value)}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                inputs.principal === preset.value
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {/* 2. Annual Interest Rate */}
      <div className="flex flex-col gap-2.5 pt-2 border-t border-slate-100">
        <div className="flex items-center justify-between">
          <label htmlFor="interest-rate-input" className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
            Annual Interest Rate (% p.a.)
          </label>
          <span className="text-xs font-mono font-medium text-slate-600">
            {inputs.interestRate}% p.a.
          </span>
        </div>

        <div className="relative">
          <input
            id="interest-rate-input"
            type="number"
            min={0.1}
            max={30}
            step={0.05}
            value={inputs.interestRate || ''}
            onChange={(e) => handleRateChange(parseFloat(e.target.value))}
            className="w-full pl-3.5 pr-8 py-2.5 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-blue-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 rounded-lg text-slate-900 font-mono text-base font-semibold tabular-nums transition-all"
          />
          <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-medium text-sm">
            %
          </span>
        </div>

        {/* Slider */}
        <input
          type="range"
          min={4.0}
          max={20.0}
          step={0.1}
          value={inputs.interestRate}
          onChange={(e) => handleRateChange(parseFloat(e.target.value))}
          className="w-full mt-1"
        />

        <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
          <span>4%</span>
          <span>12%</span>
          <span>20%</span>
        </div>

        {/* Loan Type Presets */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          {loanPresets.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => handleRateChange(p.rate)}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                Math.abs(inputs.interestRate - p.rate) < 0.01
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
              }`}
            >
              {p.label} ({p.rate}%)
            </button>
          ))}
        </div>
      </div>

      {/* 3. Loan Tenure */}
      <div className="flex flex-col gap-2.5 pt-2 border-t border-slate-100">
        <div className="flex items-center justify-between">
          <label htmlFor="tenure-input" className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600"></span>
            Loan Tenure
          </label>
          {/* Unit Toggle */}
          <div className="flex items-center p-0.5 bg-slate-100 rounded-md">
            <button
              type="button"
              onClick={() => setTenureUnit('years')}
              className={`px-2 py-0.5 text-[11px] font-semibold rounded transition-all ${
                tenureUnit === 'years'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Years
            </button>
            <button
              type="button"
              onClick={() => setTenureUnit('months')}
              className={`px-2 py-0.5 text-[11px] font-semibold rounded transition-all ${
                tenureUnit === 'months'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              Months
            </button>
          </div>
        </div>

        <div className="relative">
          <input
            id="tenure-input"
            type="number"
            min={tenureUnit === 'years' ? 1 : 6}
            max={tenureUnit === 'years' ? 35 : 420}
            step={tenureUnit === 'years' ? 0.5 : 1}
            value={tenureUnit === 'years' ? inputs.tenureYears : inputs.tenureMonths}
            onChange={(e) =>
              tenureUnit === 'years'
                ? handleTenureYearsChange(parseFloat(e.target.value))
                : handleTenureMonthsChange(parseInt(e.target.value, 10))
            }
            className="w-full pl-3.5 pr-16 py-2.5 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-blue-500 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 rounded-lg text-slate-900 font-mono text-base font-semibold tabular-nums transition-all"
          />
          <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-medium text-xs">
            {tenureUnit === 'years' ? 'Years' : 'Months'}
          </span>
        </div>

        {/* Slider */}
        <input
          type="range"
          min={1}
          max={30}
          step={1}
          value={inputs.tenureYears}
          onChange={(e) => handleTenureYearsChange(parseFloat(e.target.value))}
          className="w-full mt-1"
        />

        <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
          <span>1 Year</span>
          <span>15 Years</span>
          <span>30 Years</span>
        </div>

        {/* Quick Tenure Buttons */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          {tenurePresets.map((yrs) => (
            <button
              key={yrs}
              type="button"
              onClick={() => handleTenureYearsChange(yrs)}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                Math.round(inputs.tenureYears) === yrs
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
              }`}
            >
              {yrs} Years
            </button>
          ))}
        </div>
      </div>

      {/* 4. Start Month & Calendar Schedule Anchor */}
      <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-4">
        <label htmlFor="start-date-input" className="text-xs font-semibold text-slate-700 flex items-center gap-1.5">
          <Calendar className="w-3.5 h-3.5 text-slate-400" />
          First EMI Month
        </label>
        <input
          id="start-date-input"
          type="month"
          value={inputs.startDate}
          onChange={(e) => update({ startDate: e.target.value || '2026-11' })}
          className="px-3 py-1.5 bg-slate-50 border border-slate-200 hover:border-slate-300 focus:border-blue-500 focus:bg-white focus:outline-none rounded-md text-xs font-medium text-slate-800 transition-all"
        />
      </div>

      {/* 5. Optional Prepayment Section */}
      <div className="pt-3 border-t border-slate-200">
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5 transition-all">
          <div className="flex items-center justify-between gap-3">
            <label className="flex items-center gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={inputs.hasPrepayment}
                onChange={(e) => update({ hasPrepayment: e.target.checked })}
                className="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500/30 cursor-pointer"
              />
              <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-emerald-600" />
                Add Prepayment / Part-Payment
              </span>
            </label>
            <button
              type="button"
              onClick={() => setShowPrepaymentHelp(!showPrepaymentHelp)}
              className="text-slate-400 hover:text-slate-600 text-xs p-1 rounded"
              title="What is Prepayment?"
            >
              <HelpCircle className="w-3.5 h-3.5" />
            </button>
          </div>

          {showPrepaymentHelp && (
            <p className="mt-2 text-[11px] text-slate-600 bg-white p-2.5 rounded border border-slate-200 leading-relaxed">
              Prepaying extra principal directly reduces your outstanding balance, saving you substantial interest
              and allowing you to finish your loan years earlier!
            </p>
          )}

          {inputs.hasPrepayment && (
            <div className="mt-3.5 pt-3 border-t border-slate-200 flex flex-col gap-3.5">
              {/* Prepayment Type Selector */}
              <div>
                <label className="text-[11px] font-semibold text-slate-600 mb-1.5 block">
                  Prepayment Frequency
                </label>
                <div className="grid grid-cols-3 gap-1.5 p-1 bg-white border border-slate-200 rounded-lg">
                  <button
                    type="button"
                    onClick={() => update({ prepaymentType: 'one-time' })}
                    className={`py-1.5 px-2 text-xs font-semibold rounded-md transition-all ${
                      inputs.prepaymentType === 'one-time'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    One-Time Lump Sum
                  </button>
                  <button
                    type="button"
                    onClick={() => update({ prepaymentType: 'recurring-monthly' })}
                    className={`py-1.5 px-2 text-xs font-semibold rounded-md transition-all ${
                      inputs.prepaymentType === 'recurring-monthly'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Monthly Extra
                  </button>
                  <button
                    type="button"
                    onClick={() => update({ prepaymentType: 'recurring-yearly' })}
                    className={`py-1.5 px-2 text-xs font-semibold rounded-md transition-all ${
                      inputs.prepaymentType === 'recurring-yearly'
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Yearly Lump Sum
                  </button>
                </div>
              </div>

              {/* Prepayment Amount */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label htmlFor="prepay-amount-input" className="text-[11px] font-semibold text-slate-600">
                    {inputs.prepaymentType === 'one-time'
                      ? 'Lump Sum Prepayment Amount (₹)'
                      : inputs.prepaymentType === 'recurring-monthly'
                      ? 'Additional Monthly Amount (₹)'
                      : 'Annual Prepayment Amount (₹)'}
                  </label>
                  <span className="text-[11px] font-medium text-emerald-600 tabular-nums">
                    {numberToIndianWords(inputs.prepaymentAmount)}
                  </span>
                </div>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-medium text-xs">
                    ₹
                  </span>
                  <input
                    id="prepay-amount-input"
                    type="number"
                    min={1000}
                    step={5000}
                    value={inputs.prepaymentAmount || ''}
                    onChange={(e) => update({ prepaymentAmount: parseFloat(e.target.value) || 0 })}
                    className="w-full pl-7 pr-3 py-1.5 bg-white border border-slate-200 focus:border-blue-500 focus:outline-none rounded-lg text-slate-900 font-mono text-xs font-semibold tabular-nums"
                  />
                </div>

                {/* Prepayment quick chips */}
                <div className="flex flex-wrap items-center gap-1 mt-1.5">
                  {prepaymentPresets.map((preset) => (
                    <button
                      key={preset.value}
                      type="button"
                      onClick={() => update({ prepaymentAmount: preset.value })}
                      className={`px-2 py-0.5 text-[11px] font-medium rounded transition-colors ${
                        inputs.prepaymentAmount === preset.value
                          ? 'bg-emerald-600 text-white'
                          : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Start Month */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="prepay-start-input" className="text-[11px] font-semibold text-slate-600 mb-1 block">
                    {inputs.prepaymentType === 'one-time' ? 'Apply in Month #' : 'Start From Month #'}
                  </label>
                  <input
                    id="prepay-start-input"
                    type="number"
                    min={1}
                    max={inputs.tenureMonths}
                    value={inputs.prepaymentStartMonth}
                    onChange={(e) =>
                      update({
                        prepaymentStartMonth: Math.max(1, parseInt(e.target.value, 10) || 1),
                      })
                    }
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 focus:border-blue-500 focus:outline-none rounded-lg text-slate-900 font-mono text-xs font-semibold tabular-nums"
                  />
                </div>

                {/* Strategy */}
                <div>
                  <label htmlFor="prepay-target-select" className="text-[11px] font-semibold text-slate-600 mb-1 block">
                    Impact Strategy
                  </label>
                  <select
                    id="prepay-target-select"
                    value={inputs.prepaymentTarget}
                    onChange={(e) => update({ prepaymentTarget: e.target.value as PrepaymentTarget })}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-200 focus:border-blue-500 focus:outline-none rounded-lg text-slate-900 text-xs font-medium"
                  >
                    <option value="reduce-tenure">Reduce Tenure (Saves More Interest)</option>
                    <option value="reduce-emi">Reduce EMI (Lower Monthly Burden)</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
